import Vue from 'vue'
import {AgGridVue} from 'ag-grid-vue';

Vue.component("ag-grid-vue",AgGridVue)