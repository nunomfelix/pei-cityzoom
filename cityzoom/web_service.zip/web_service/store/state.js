export default () => ({
    user: {},
    jwt: '',
    verticals: [],
    devices: [],
    heatmap: {},
})